title: 小技巧：Maven依赖复制
date: '2019-12-03 21:28:22'
updated: '2019-12-03 21:28:22'
tags: [maven, 小技巧]
permalink: /articles/2019/12/03/1575379702601.html
---
![](https://img.hacpai.com/bing/20180401.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

本周学习了使用maven copy dependencies插件，将工程依赖包复制到指定目目录。
1. 在maven工程中添加工maven-dependency-plugin
~~~
    <build>
        <plugins>
            <!-- https://mvnrepository.com/artifact/org.apache.maven.plugins/maven-dependency-plugin -->
            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-dependency-plugin</artifactId>
                <configuration>
                    <!--ignore jaxb -->
                    <excludeArtifactIds>jaxb-impl,jaxb-parent</excludeArtifactIds>
                </configuration>
            </plugin>
        </plugins>
    </build>
~~~
2.  在工程根目录执行如下命令：
~~~
mvn dependency:copy-dependencies -DoutputDirectory=/target/lib -Dmdep.useRepositoryLayout=true -Dmdep.addParentPoms=true -Dmdep.copyPom=true
~~~
3. 相关参数见以下链接
* [maven-dependency-plugin](https://maven.apache.org/plugins/maven-dependency-plugin/copy-dependencies-mojo.html)
* [maven-dependency-plugin usage](https://maven.apache.org/plugins/maven-dependency-plugin/usage.html)

