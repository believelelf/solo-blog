title: 问题排查：使用pdfbox将pdf转image时STSong-Light字体中文乱码
date: '2019-11-07 20:27:18'
updated: '2019-11-07 20:27:18'
tags: [STSong-Light, pdfbox, pdf2image, 中文乱码]
permalink: /articles/2019/11/07/1573129637768.html
---
![](https://img.hacpai.com/bing/20180923.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

今天帮同事解决了一个使用pdfbox将pdf转image时STSong-Light字体中文乱码的问题。问题出现原因及解决方案如文所述。

### 问题示例代码
~~~
public class PDF2Image {

    private static final Logger LOGGER = LoggerFactory.getLogger(PDF2Image.class);

    private static final int POINTS_IN_INCH = 72;

    public static void pdf2Image(String filename) {
        try (PDDocument document = PDDocument.load(PDF2Image.class.getResourceAsStream("/" + filename))) {
            PDFRenderer pdfRenderer = new PDFRenderer(document);
            int pageCounter = 0;
            for (PDPage page : document.getPages()) {
                // note that the page number parameter is zero based
                BufferedImage bim = pdfRenderer.renderImageWithDPI(pageCounter, 300, ImageType.RGB);
                // suffix in filename will be used as the file format
                ImageIOUtil.writeImage(bim, filename + "-" + (pageCounter++) + ".png", 300);
            }
        } catch (IOException e) {
            LOGGER.error("render image error:[{}]", filename, e);
        }

    }

    public static void main(String[] args) {
        pdf2Image("525d747dd4fa44b5867241b664b779f0.pdf");
    }


}
~~~

### 异常现象
生成的图片里中文字符显示为方块。

### 异常日志
~~~
  11月 06, 2019 10:45:14 下午 org.apache.pdfbox.pdmodel.font.FileSystemFontProvider loadDiskCache
  警告: New fonts found, font cache will be re-built
  11月 06, 2019 10:45:14 下午 org.apache.pdfbox.pdmodel.font.FileSystemFontProvider <init>
  警告: Building on-disk font cache, this may take a while
  11月 06, 2019 10:45:18 下午 org.apache.pdfbox.pdmodel.font.FileSystemFontProvider <init>
  警告: Finished building on-disk font cache, found 245 fonts
  11月 06, 2019 10:45:18 下午 org.apache.pdfbox.pdmodel.font.PDCIDFontType0 <init>
  警告: Using fallback MT-Extra for CID-keyed font STSong-Light
  11月 06, 2019 10:45:24 下午 org.apache.pdfbox.rendering.CIDType0Glyph2D getPathForCharacterCode
  警告: No glyph for 22826 (CID 0dfe) in font STSong-Light
  11月 06, 2019 10:45:24 下午 org.apache.pdfbox.rendering.CIDType0Glyph2D getPathForCharacterCode
  警告: No glyph for 24179 (CID 0bdc) in font STSong-Light
 ~~~
 
### 异常原因
STSong-Light为Adobe版本字体，只能用于Adobe Reader，其他软件使用时只能找替换字体。参见[Cmap_info.txt](https://github.com/itext/itext7/blob/develop/font-asian/src/main/resources/com/itextpdf/io/font/cmap_info.txt)
 
### 解决方案
pdfbox在FontMapperImpl里提供了两种字体容错方案
1.  字体替换映射：substitutes
2.  基于规则自动查找匹配字体：org.apache.pdfbox.pdmodel.font.FontMapperImpl#getFontMatches(org.apache.pdfbox.pdmodel.font.PDFontDescriptor, org.apache.pdfbox.pdmodel.font.PDCIDSystemInfo)

但存在的问题是：
1. substitutes只支持14种标准字符，STSong-Light不在其中，且final class FontMapperImpl，在包外不可见。
2. 基于规则自动查找匹配字体,在匹配规则中fallback的字体不能适配到合适字体，优先级高的字体为MalgunGothic-Semilight等，其存在适配性问题。另外PDCIDFontType0#PDCIDFontType0(COSDictionary, PDType0Font)创建时字体时对于PDFontDescriptor没有提供设置接口，对于匹配规则修改很困难。

基于目前的了解，较好的方案为将FontMapperImpl复制到当前工程目录，在substitutes中增加映射字体STSong-Light->STFangsong
~~~
package org.apache.pdfbox.pdmodel.font;

import org.apache.fontbox.FontBoxFont;
import org.apache.fontbox.ttf.OpenTypeFont;
import org.apache.fontbox.ttf.TTFParser;
import org.apache.fontbox.ttf.TrueTypeFont;
import org.apache.fontbox.type1.Type1Font;

import java.io.IOException;
import java.io.InputStream;
import java.util.*;

/**
 * Font mapper, locates non-embedded fonts via a pluggable FontProvider.
 *
 * @author John Hewson
 */
final class FontMapperImpl implements FontMapper
{
    private static final FontCache fontCache = new FontCache(); // todo: static cache isn't ideal
    private FontProvider fontProvider;
    private Map<String, FontInfo> fontInfoByName;
    private final TrueTypeFont lastResortFont;

    /** Map of PostScript name substitutes, in priority order. */
    private final Map<String, List<String>> substitutes = new HashMap<String, List<String>>();

    FontMapperImpl()
    {
        // substitutes for standard 14 fonts
        substitutes.put("Courier",
                Arrays.asList("CourierNew", "CourierNewPSMT", "LiberationMono", "NimbusMonL-Regu"));
        substitutes.put("Courier-Bold",
                Arrays.asList("CourierNewPS-BoldMT", "CourierNew-Bold", "LiberationMono-Bold",
                        "NimbusMonL-Bold"));
        substitutes.put("Courier-Oblique",
                Arrays.asList("CourierNewPS-ItalicMT","CourierNew-Italic",
                        "LiberationMono-Italic", "NimbusMonL-ReguObli"));
        substitutes.put("Courier-BoldOblique",
                Arrays.asList("CourierNewPS-BoldItalicMT","CourierNew-BoldItalic",
                        "LiberationMono-BoldItalic", "NimbusMonL-BoldObli"));
        substitutes.put("Helvetica",
                Arrays.asList("ArialMT", "Arial", "LiberationSans", "NimbusSanL-Regu"));
        substitutes.put("Helvetica-Bold",
                Arrays.asList("Arial-BoldMT", "Arial-Bold", "LiberationSans-Bold",
                        "NimbusSanL-Bold"));
        substitutes.put("Helvetica-Oblique",
                Arrays.asList("Arial-ItalicMT", "Arial-Italic", "Helvetica-Italic",
                        "LiberationSans-Italic", "NimbusSanL-ReguItal"));
        substitutes.put("Helvetica-BoldOblique",
                Arrays.asList("Arial-BoldItalicMT", "Helvetica-BoldItalic",
                        "LiberationSans-BoldItalic", "NimbusSanL-BoldItal"));
        substitutes.put("Times-Roman",
                Arrays.asList("TimesNewRomanPSMT", "TimesNewRoman", "TimesNewRomanPS",
                        "LiberationSerif", "NimbusRomNo9L-Regu"));
        substitutes.put("Times-Bold",
                Arrays.asList("TimesNewRomanPS-BoldMT", "TimesNewRomanPS-Bold",
                        "TimesNewRoman-Bold", "LiberationSerif-Bold",
                        "NimbusRomNo9L-Medi"));
        substitutes.put("Times-Italic",
                Arrays.asList("TimesNewRomanPS-ItalicMT", "TimesNewRomanPS-Italic",
                        "TimesNewRoman-Italic", "LiberationSerif-Italic",
                        "NimbusRomNo9L-ReguItal"));
        substitutes.put("Times-BoldItalic",
                Arrays.asList("TimesNewRomanPS-BoldItalicMT", "TimesNewRomanPS-BoldItalic",
                        "TimesNewRoman-BoldItalic", "LiberationSerif-BoldItalic",
                        "NimbusRomNo9L-MediItal"));
        substitutes.put("Symbol", Arrays.asList("Symbol", "SymbolMT", "StandardSymL"));
        substitutes.put("ZapfDingbats", Arrays.asList("ZapfDingbatsITC", "Dingbats", "MS-Gothic"));
        // FIXME believelelf STSong-Light->STFangsong
        substitutes.put("STSong-Light", Arrays.asList("STFangsong"));

        // Acrobat also uses alternative names for Standard 14 fonts, which we map to those above
        // these include names such as "Arial" and "TimesNewRoman"
        for (String baseName : Standard14Fonts.getNames())
        {
            if (!substitutes.containsKey(baseName))
            {
                String mappedName = Standard14Fonts.getMappedFontName(baseName);
                substitutes.put(baseName, copySubstitutes(mappedName));
            }
        }

        // -------------------------

        try
        {
            String ttfName = "/org/apache/pdfbox/resources/ttf/LiberationSans-Regular.ttf";
            InputStream ttfStream = FontMapper.class.getResourceAsStream(ttfName);
            if (ttfStream == null)
            {
                throw new IOException("Error loading resource: " + ttfName);
            }
            TTFParser ttfParser = new TTFParser();
            lastResortFont = ttfParser.parse(ttfStream);
        }
        catch (IOException e)
        {
            throw new RuntimeException(e);
        }
    }
    
    // 以下省略......
}    
~~~ 

### 后续改进建议

1. 针对substitutes暴露修改接口，这一点在1.8版本的官方文档里有提到映射修改机制，但2.0里去除了。
~~~
PDFBox will load Resources/PDFBox_External_Fonts.properties off of the classpath to map font names to TTF font files. The UNKNOWN_FONT property in that file will tell PDFBox which font to use when no mapping exists.
~~~
2. 优化getFontMatches匹配算法


### 参考资料：
1. [cmap_info.txt](https://github.com/itext/itext7/blob/develop/font-asian/src/main/resources/com/itextpdf/io/font/cmap_info.txt)
2. [复现问题所用的示例工工程PDF2Image](https://github.com/believelelf/PDF2Image)

### 注意：
由于数据安全问题，525d747dd4fa44b5867241b664b779f0.pdf未在仓库中包含。pdf示例文件请自行创建。

