title: 译文：JMH的概述
date: '2019-10-30 23:25:09'
updated: '2019-10-30 23:25:09'
tags: [JMH, Benchmark, 性能分析, Java]
permalink: /articles/2019/10/30/1572449109376.html
---
![](https://img.hacpai.com/bing/20190320.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

最近在写一个分布式ID生成服务，需要做微基准测试，因此开始学习JMH，计划先从翻译官网手册入手，分10篇博客完成整个翻译工作。本文为系列的第一篇：JMH的概述。

原文地址：[Code Tools: jmh](http://openjdk.java.net/projects/code-tools/jmh/)

### 代码工具：jmh
JMH是一个用于构建、运行和分析Java语言或其他基于JVM语言的基准测试程序的工具。它可以提供从微观到宏观的多个测试维度。

#### 基本注意事项
推荐通过使用Maven去构建一个依赖于你应用程序jar文件的独立工程来运行JMH基准测试。这种方式更适合正确初始化基准测试并且产生正确的结果。当然，也可以从一个已经存在的项目运行基准测试，甚至在IDE中也可以，但这样的设置将带来更多的复杂性而且结果也更加不可靠。

在所有情况下，基准测试的关键都是使用注解或字节码处理器去生成合成的基准测试代码。Maven archetypes 是一种生成基准测试代码的主要方式。我们强烈推荐新用户使用Maven archetypes去设置正确的环境。

#### 首选用法：命令行

* **新建基准测试项目** 下列命令行将在test目录生成一个JMH驱动的项目。
    ~~~
    $ mvn archetype:generate \
          -DinteractiveMode=false \
          -DarchetypeGroupId=org.openjdk.jmh \
          -DarchetypeArtifactId=jmh-java-benchmark-archetype \
          -DgroupId=org.sample \
          -DartifactId=test \
          -Dversion=1.0
    ~~~

如果你想对其他基于JVM的语言进行基准测试，你可以从这个[列表](http://central.maven.org/maven2/org/openjdk/jmh/)中选择另一种语言的archetype，只需替换指定的artifact ID即可。另外使用其他archetypes可能要求额外修改构建配置，具体可以参考所生成项目的pom.xml文件。

* **构建基准测试** 在基准测试项目生成后，你可以通过以下Maven命令来进行构建：
    ~~~
    $ cd test/
    $ mvn clean install
    ~~~


* **运行基准测试项目** 在项目构建完成之后，你将获得一个自包含的可执行的Jar,它包含你的基准测试代码和所有必要的JMH基础结构代码：
    ~~~
    $ java -jar target/benchmarks.jar
    ~~~
    *以-h选项运行命令，你能看见更多命令行选项。*

在处理大型项目时，通常将基准测试代码保存一个单独的子项目中，并把它作为待测试模块的一个普通依赖。

#### IDE支持
虽然推荐使用命令行去构建基准测试，但可能仍有些人希望使用IDE。不同的IDE用户体验不同，但我们这里只概述相通的部分。通常不推荐在IDE中运行基准测试，因为这意味着基准测试是在不可控的环境中运行的。

* **新建基准测试项目** 一些IDE提供从指定archetype创建Maven项目的图形界面。确保你的IDE有中央仓库的archetype列表，而且能够从中找到*org.openjdk.jmh:jmh-${lang}-benchmark-archetype*。或者，你可以像上面所述使用命令行生成基准测试项目。

    **注意** JMH和Junit那样的典型测试库用法不一样。简单地添加jmh-core.jar到你的构建中不足以运行基准测试。

* **构建基准测试** 大多数IDE能够打开或导入Maven项目，并且从Maven项目配置推断出构建配置。IDEA和Netbeans比较容易构建JMH基准测试项目。Eclipse则可能需要在构建配置中设置要运行的JMH注解处理器。

* **运行基准测试** IDE中没有对运行基准测试的直接支持，但我们可以使用JMH Java API来调用基准测试。通常的做法写一个main方法，在里面调用JMH Java API.在[JMH Samples](http://hg.openjdk.java.net/code-tools/jmh/file/tip/jmh-samples/src/main/java/org/openjdk/jmh/samples/)中可以看到对应的示例。在你运行任何基准测试之前，项目构建是必需的。大多数IDE可以进行自动构建，但一些IDE可能需要在运行之前显式添加构建动作：添加一个Maven目标动作“install”是有帮助的。


#### 其他构建系统
我们没有为其他构建系统提供构建脚本支持，但社区对于Gradle,sbt等提供了支持，此外也可能包括一些其他构建系统，你可以参考下方的链接章节。如果您想要使用一个其他构建系统来构建基准测试项目，您可以参考[Ant示例](http://hg.openjdk.java.net/code-tools/jmh/file/tip/jmh-ant-sample/)，该示例描述了使用Ant构建JMH基准项目的步骤。

#### 基于最新版本JMH构建基准测试项目
在一些基准测试案例中，你可能需要用到包含补丁、最新特性和API的非稳定版本JMH.这个部分将介绍如何在你的项目中使用最新版本JMH。

1. 使用[Mercurial](http://mercurial.selenic.com/)检出JMH代码
~~~
$ hg clone http://hg.openjdk.java.net/code-tools/jmh/ jmh
~~~
2. 构建JMH。你可以手动跳过测试阶段。
~~~
$ cd jmh/
$ mvn clean install -DskipTests
~~~
*你只要执行这个步骤一次，Maven将会把JMH部署到你本地机器的Maven仓库中。*
3. 如果你已经有了基准测试项目，那么将JMH依赖项版本更改为最新快照版本就足够了(在[父POM](http://hg.openjdk.java.net/code-tools/jmh/file/tip/pom.xml#l33)中查找实际的最新版本).如果没有，创建一个JMH基准测试项目，同时改变它的版本。
4. 以上动作完成后，通过运行如下命令构建基准测试项目。
~~~
$ mvn clean install
$ java -jar target/benchmarks.jar
~~~

#### 如何获取支持
在你执行基准测试和/或使用JMH特性之前，请确保做了这些:
* **已经阅读JMH注解的Javadocs和示例程序.** 通过[JMH samples](http://hg.openjdk.java.net/code-tools/jmh/file/tip/jmh-samples/src/main/java/org/openjdk/jmh/samples/)来熟悉JMH API、用例，以及在构建微基准测试和使用JMH过程的陷阱。

* **你的基准测试方面需要通过同行评审。** 不要以为一个好的工具就能神奇地让你从基准测试陷阱中解脱出来。我们只承诺更好地避免问题，但不能承诺完全避免它们。

在你寻求支持之前尝试这些：

* **Archetypes提供的黄金构建配置。**  尝试生成一个空的JMH基准测试项目，并把基准测试代码移植到那里。当你尝试更新到一个新的JMH版本时，尝试这一点很重要，因为构建配置中的微小差异可能导致你所看到的失败。

* **正在开发的代码通常是更精简，更有意义的，更好的。** 尝试运行最新版本的JMH，看看问题是否已经被修复。

* **看看你的问题是否已经讨论过了** 查看邮件列表归档，看看是否已经有了答案。

如果这些都没有帮助，欢迎你使用[JMH mailing list](http://mail.openjdk.java.net/mailman/listinfo/jmh-dev)。

#### 链接
* [JMH Samples](http://hg.openjdk.java.net/code-tools/jmh/file/tip/jmh-samples/src/main/java/org/openjdk/jmh/samples/)
* [JMH Source Repository](http://hg.openjdk.java.net/code-tools/jmh/) (includes Changelog)
* [JMH Mailing List](http://mail.openjdk.java.net/mailman/listinfo/jmh-dev)

#### 相关项目
以下这些项目由社区提供，而非OpenJDK/JMH项目的开发者。
* [Gradle JMH Plugin](https://github.com/melix/jmh-gradle-plugin)
* [Scala SBT JMH Plugin](https://github.com/ktoso/sbt-jmh)
* [IntelliJ IDEA JMH Plugin](https://github.com/artyushov/idea-jmh-plugin)
* [Jenkins JMH Plugin](https://github.com/brianfromoregon/jmh-plugin)
* [Teamcity JMH Plugin](https://github.com/presidentio/teamcity-plugin-jmh)




